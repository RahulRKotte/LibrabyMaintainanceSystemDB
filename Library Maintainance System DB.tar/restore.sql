--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 15.1
-- Dumped by pg_dump version 15.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE library_ms;
--
-- Name: library_ms; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE library_ms WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'English_India.1252';


ALTER DATABASE library_ms OWNER TO postgres;

\connect library_ms

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: author; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.author (
    id integer NOT NULL,
    first_name character varying(300),
    last_name character varying(300)
);


ALTER TABLE public.author OWNER TO postgres;

--
-- Name: book; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.book (
    id integer NOT NULL,
    title character varying(500),
    category_id integer,
    publication_date date,
    copies_owned integer
);


ALTER TABLE public.book OWNER TO postgres;

--
-- Name: book_author; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.book_author (
    book_id integer,
    author_id integer
);


ALTER TABLE public.book_author OWNER TO postgres;

--
-- Name: category; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.category (
    id integer NOT NULL,
    category_name character varying(100)
);


ALTER TABLE public.category OWNER TO postgres;

--
-- Name: fine; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fine (
    id integer NOT NULL,
    book_id integer,
    loan_id integer,
    fine_date date,
    fine_amount integer
);


ALTER TABLE public.fine OWNER TO postgres;

--
-- Name: fine_payment; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fine_payment (
    id integer NOT NULL,
    member_id integer,
    payment_date date,
    payment_amount integer
);


ALTER TABLE public.fine_payment OWNER TO postgres;

--
-- Name: loan; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.loan (
    id integer NOT NULL,
    book_id integer,
    member_id integer,
    loan_date date,
    returned_date date
);


ALTER TABLE public.loan OWNER TO postgres;

--
-- Name: member; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.member (
    id integer NOT NULL,
    first_name character varying(300),
    last_name character varying(300),
    joined_date date,
    active_status_id integer
);


ALTER TABLE public.member OWNER TO postgres;

--
-- Name: member_status; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.member_status (
    id integer NOT NULL,
    status_value character varying(50)
);


ALTER TABLE public.member_status OWNER TO postgres;

--
-- Name: reservation; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.reservation (
    id integer NOT NULL,
    book_id integer,
    member_id integer,
    reservation_date date,
    reservation_status_id integer
);


ALTER TABLE public.reservation OWNER TO postgres;

--
-- Name: reservation_status; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.reservation_status (
    id integer NOT NULL,
    status_value character varying(50)
);


ALTER TABLE public.reservation_status OWNER TO postgres;

--
-- Data for Name: author; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.author (id, first_name, last_name) FROM stdin;
\.
COPY public.author (id, first_name, last_name) FROM '$$PATH$$/3388.dat';

--
-- Data for Name: book; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.book (id, title, category_id, publication_date, copies_owned) FROM stdin;
\.
COPY public.book (id, title, category_id, publication_date, copies_owned) FROM '$$PATH$$/3387.dat';

--
-- Data for Name: book_author; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.book_author (book_id, author_id) FROM stdin;
\.
COPY public.book_author (book_id, author_id) FROM '$$PATH$$/3389.dat';

--
-- Data for Name: category; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.category (id, category_name) FROM stdin;
\.
COPY public.category (id, category_name) FROM '$$PATH$$/3386.dat';

--
-- Data for Name: fine; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.fine (id, book_id, loan_id, fine_date, fine_amount) FROM stdin;
\.
COPY public.fine (id, book_id, loan_id, fine_date, fine_amount) FROM '$$PATH$$/3395.dat';

--
-- Data for Name: fine_payment; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.fine_payment (id, member_id, payment_date, payment_amount) FROM stdin;
\.
COPY public.fine_payment (id, member_id, payment_date, payment_amount) FROM '$$PATH$$/3393.dat';

--
-- Data for Name: loan; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.loan (id, book_id, member_id, loan_date, returned_date) FROM stdin;
\.
COPY public.loan (id, book_id, member_id, loan_date, returned_date) FROM '$$PATH$$/3394.dat';

--
-- Data for Name: member; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.member (id, first_name, last_name, joined_date, active_status_id) FROM stdin;
\.
COPY public.member (id, first_name, last_name, joined_date, active_status_id) FROM '$$PATH$$/3391.dat';

--
-- Data for Name: member_status; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.member_status (id, status_value) FROM stdin;
\.
COPY public.member_status (id, status_value) FROM '$$PATH$$/3390.dat';

--
-- Data for Name: reservation; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.reservation (id, book_id, member_id, reservation_date, reservation_status_id) FROM stdin;
\.
COPY public.reservation (id, book_id, member_id, reservation_date, reservation_status_id) FROM '$$PATH$$/3392.dat';

--
-- Data for Name: reservation_status; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.reservation_status (id, status_value) FROM stdin;
\.
COPY public.reservation_status (id, status_value) FROM '$$PATH$$/3385.dat';

--
-- Name: author pk_author; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.author
    ADD CONSTRAINT pk_author PRIMARY KEY (id);


--
-- Name: book pk_book; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.book
    ADD CONSTRAINT pk_book PRIMARY KEY (id);


--
-- Name: category pk_category; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.category
    ADD CONSTRAINT pk_category PRIMARY KEY (id);


--
-- Name: fine pk_fine; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fine
    ADD CONSTRAINT pk_fine PRIMARY KEY (id);


--
-- Name: fine_payment pk_fine_payment; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fine_payment
    ADD CONSTRAINT pk_fine_payment PRIMARY KEY (id);


--
-- Name: loan pk_loan; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.loan
    ADD CONSTRAINT pk_loan PRIMARY KEY (id);


--
-- Name: member pk_member; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.member
    ADD CONSTRAINT pk_member PRIMARY KEY (id);


--
-- Name: member_status pk_memberstatus; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.member_status
    ADD CONSTRAINT pk_memberstatus PRIMARY KEY (id);


--
-- Name: reservation_status pk_res_status; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reservation_status
    ADD CONSTRAINT pk_res_status PRIMARY KEY (id);


--
-- Name: reservation pk_reservation; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reservation
    ADD CONSTRAINT pk_reservation PRIMARY KEY (id);


--
-- Name: book fk_book_category; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.book
    ADD CONSTRAINT fk_book_category FOREIGN KEY (category_id) REFERENCES public.category(id);


--
-- Name: book_author fk_bookauthor_author; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.book_author
    ADD CONSTRAINT fk_bookauthor_author FOREIGN KEY (author_id) REFERENCES public.author(id);


--
-- Name: book_author fk_bookauthor_book; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.book_author
    ADD CONSTRAINT fk_bookauthor_book FOREIGN KEY (book_id) REFERENCES public.book(id);


--
-- Name: fine fk_fine_book; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fine
    ADD CONSTRAINT fk_fine_book FOREIGN KEY (book_id) REFERENCES public.book(id);


--
-- Name: fine fk_fine_loan; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fine
    ADD CONSTRAINT fk_fine_loan FOREIGN KEY (loan_id) REFERENCES public.loan(id);


--
-- Name: fine_payment fk_finepay_member; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fine_payment
    ADD CONSTRAINT fk_finepay_member FOREIGN KEY (member_id) REFERENCES public.member(id);


--
-- Name: loan fk_loan_book; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.loan
    ADD CONSTRAINT fk_loan_book FOREIGN KEY (book_id) REFERENCES public.book(id);


--
-- Name: loan fk_loan_member; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.loan
    ADD CONSTRAINT fk_loan_member FOREIGN KEY (member_id) REFERENCES public.member(id);


--
-- Name: member fk_member_status; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.member
    ADD CONSTRAINT fk_member_status FOREIGN KEY (active_status_id) REFERENCES public.member_status(id);


--
-- Name: reservation fk_res_book; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reservation
    ADD CONSTRAINT fk_res_book FOREIGN KEY (book_id) REFERENCES public.book(id);


--
-- Name: reservation fk_res_member; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reservation
    ADD CONSTRAINT fk_res_member FOREIGN KEY (member_id) REFERENCES public.member(id);


--
-- PostgreSQL database dump complete
--

